TOWNSQUARE INTERACTIVE - FULL HTML SOURCE ARCHIVE
Captured: September 7, 2026

WHAT'S IN HERE
--------------
www.townsquareinteractive.com/   Every page of the main site, saved as <path>/index.html
                                 (e.g. /grow/ -> www.townsquareinteractive.com/grow/index.html).
                                 Includes all sitemap pages (home, services, industries, locations,
                                 case studies, projects, legal pages, blog + all posts) plus every
                                 page discovered by crawling internal links (blog category / tag /
                                 author archives and all their pagination pages).
                                 _404-page-not-found.html is the site's 404 error page.
helpcenter.townsquareinteractive.com/   The Zendesk help center. The help center is private
                                 (every page redirects to sign-in), so this folder holds the
                                 end-user sign-in page (= the user login page), the agent
                                 sign-in page, and the password reset / request page.
careers.townsquareinteractive.com/      The careers site home page.
MANIFEST.csv                     URL -> file mapping for every page, with page title and size.

HOW IT WAS CAPTURED
-------------------
Raw server HTML (view-source equivalent), fetched with a desktop Chrome user agent, following
redirects. Assets (images, CSS, JS) are NOT included - only HTML. Links in the files still point
at the live site.

NOT INCLUDED / LIMITATIONS
--------------------------
- Help center articles: locked behind login; only reachable pages are the auth pages above.
- Zendesk "Sign up" page (/auth/v3/register) and /hc/ paths: protected by a Cloudflare browser
  challenge that blocks non-browser fetches.
- Dead links found on the site (all return 404 and were skipped):
  /automated-email-sms/, /business-management-platform/, /business-email-managment/,
  /free-report/, /social-ads/, /what-is-crm/, /blog/6-google-business-profile-tips-for-contractors/,
  /blog/how-to-get-more-google-reviews/, and ~90 legacy /YYYY/MM/DD/ blog URLs.
- /contact/, /seo/, /listings/ redirect to PNG images, not pages.
- Feeds, wp-json, wp-admin and asset URLs were intentionally excluded.
